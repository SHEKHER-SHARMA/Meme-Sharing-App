# Meme-Share
An android app which lets you share memes among your friends.

Youtube playlist for this Project: https://bit.ly/3hGQOfS
</br>
</br>
[![Watch the video](https://img.youtube.com/vi/W3lgZuaIuqU/hqdefault.jpg)](https://youtu.be/W3lgZuaIuqU)
